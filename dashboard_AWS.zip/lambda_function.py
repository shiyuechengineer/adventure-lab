import configparser
from datetime import datetime
import json
import sys

import requests

from chatbot import *
from snapshot import *


# Store credentials in a separate file
def gather_credentials():
    cp = configparser.ConfigParser()
    try:
        cp.read('credentials.ini')
        org_key = cp.get('meraki', 'key1')
        cam_key = cp.get('meraki', 'key2')
        if cam_key == '':
            cam_key = org_key
        labels = cp.get('meraki', 'cameras')
        if labels != '':
            labels = labels.split(',')
            cameras = [label.strip() for label in labels]
        else:
            cameras = []
        lookback = int(cp.get('meraki', 'lookback'))
        shared_secret = cp.get('meraki', 'secret')
        chatbot_token = cp.get('chatbot', 'token')
        user_email = cp.get('chatbot', 'email')
    except:
        print('Missing credentials or problem with input file!')
        sys.exit(2)
    return org_key, cam_key, cameras, lookback, shared_secret, chatbot_token, user_email


# Main Lambda function
def lambda_handler(event, context):
    # Import user inputs from credentials.ini file, and use bot token to get ID
    (org_key, cam_key, cameras, lookback, shared_secret, chatbot_token, user_email) = gather_credentials()
    headers = {
        'content-type': 'application/json; charset=utf-8',
        'authorization': f'Bearer {chatbot_token}'
    }
    session = requests.Session()

    # Webhook event/metadata received, so now retrieve the actual message for the event
    webhook_event = json.loads(event['body'])
    print(webhook_event)

    # Do not continue if shared secret does not match
    if shared_secret != webhook_event['sharedSecret']:
        # Except for "send test webhook" button
        if not (not webhook_event['alertId'] and not webhook_event['alertData']):
            return {'statusCode': 404, 'body': json.dumps('incorrect shared secret')}
    
    # Parse event data
    alert = webhook_event['alertType']
    data = webhook_event['alertData']
    name = data['name'] if 'name' in data else ''
    network = webhook_event['networkName']
    network = network.replace('@', '')  # @ sign messes up markdown
    network_link = webhook_event['networkUrl']
    device = webhook_event['deviceName'] if 'deviceName' in webhook_event else ''
    if device:
        device_link = webhook_event['deviceUrl']

    # Compose and format message to user
    payload = {'toPersonEmail': user_email}
    message = f'**{alert}**'
    if alert == 'Motion detected':
        # Format motion alert message with link to camera
        net_id = webhook_event['networkId']
        serial = webhook_event['deviceSerial']
        time_zone = get_network(cam_key, net_id, session)['timeZone']
        timestamp = datetime.utcfromtimestamp(data['timestamp'])    # UTC
        utc_time = pytz.utc.localize(timestamp)
        local_time = utc_time.astimezone(pytz.timezone(time_zone))
        file_name = device + ' - ' + local_time.strftime('%Y-%m-%d_%H-%M-%S')
        video = get_video_link(cam_key, net_id, serial, timestamp=str(data['timestamp']).replace('.', ''), session=session)
        message += f' - [{network}]({network_link})'
        message += f': _[{device}]({video})_'
    else:
        if name:
            message += f' - _{name}_'
        message += f': [{network}]({network_link})'
        if device:
            message += f' - _[{device}]({device_link})_'

    # Prevent the same message from being sent repeatedly in the lookback timeframe
    if already_duplicated(session, headers, message, user_email, lookback):
        message = 'MUTED!! ' + message
        print(message)

    # Include snapshot for motion detections
    elif alert == 'Motion detected':
        if 'imageUrl' in data and data['imageUrl']:  # use motion recap image if available
            file_url = data['imageUrl']
        else:
            file_url = generate_snapshot(cam_key, net_id, serial, utc_time.isoformat(), session)

        if file_url:    # download/GET image from URL
            temp_file = download_file(session, file_name, file_url)
            if temp_file:
                send_file(session, headers, payload, message, temp_file, file_type='image/jpg')
            else:
                message += ' (snapshot unsuccessfully retrieved)'
                post_message(session, headers, payload, message)
        else:
            message += ' (snapshot unsuccessfully requested)'
            post_message(session, headers, payload, message)

    # Add more alert information and format JSON
    elif data:
        message += f'  \n```{json.dumps(data, indent=2, sort_keys=True)}'[:-1]  # screwy Webex Teams formatting
        post_message(session, headers, payload, message)

    # Send the webhook without alert data
    elif message != '':
        post_message(session, headers, payload, message)

    # Let Meraki know success
    return {
        'statusCode': 200,
        'body': json.dumps('webhook received')
    }
