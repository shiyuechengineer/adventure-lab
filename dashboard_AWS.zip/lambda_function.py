import configparser
from datetime import datetime
import sys
import time

import requests

# Functions for chatbot
from chatbot import *


# Functions for snapshots
from snapshot import *


# Store credentials in a separate file
def gather_credentials():
    cp = configparser.ConfigParser()
    try:
        cp.read('credentials.ini')
        org_key = cp.get('meraki', 'key1')
        cam_key = cp.get('meraki', 'key2')
        if cam_key == '':
            cam_key = org_key
        net_id = cp.get('meraki', 'network')
        labels = cp.get('meraki', 'cameras')
        if labels != '':
            labels = labels.split(',')
            cameras = [label.strip() for label in labels]
        else:
            cameras = []
        lookback = int(cp.get('meraki', 'lookback'))
        chatbot_token = cp.get('chatbot', 'token')
        user_email = cp.get('chatbot', 'email')
    except:
        print('Missing credentials or problem with input file!')
        sys.exit(2)
    return org_key, cam_key, net_id, cameras, chatbot_token, user_email, lookback


# Main Lambda function
def lambda_handler(event, context):
    # Import user inputs from credentials.ini file, and use bot token to get ID
    (org_key, cam_key, net_id, cameras, chatbot_token, user_email, lookback) = gather_credentials()
    headers = {
        'content-type': 'application/json; charset=utf-8',
        'authorization': f'Bearer {chatbot_token}'
    }
    session = requests.Session()

    # Webhook event/metadata received, so now retrieve the actual message for the event
    webhook_event = json.loads(event['body'])
    print(webhook_event)

    # Parse event data
    alert = webhook_event['alertType']
    data = webhook_event['alertData']
    name = data['name'] if 'name' in data else ''
    network = webhook_event['networkName']
    network = network.replace('@', '')  # @ sign messes up markdown
    network_link = webhook_event['networkUrl']
    device = webhook_event['deviceName'] if 'deviceName' in webhook_event else ''
    if device:
        device_link = webhook_event['deviceUrl']

    # Compose and format message to user
    payload = {'toPersonEmail': user_email}
    message = f'**{alert}**'

    # Add snapshot if motion detected
    if alert == 'Motion detected':
        timestamp = datetime.fromtimestamp(int(data['timestamp'])).isoformat() + 'Z'
        snapshots = meraki_snapshots(session, cam_key, webhook_event['networkId'], timestamp, device)
        if snapshots:
            (name, photo, video) = snapshots[0]
            message += f' - [{network}]({network_link})'
            message += f': _[{device}]({video})_'
        else:
            message = ''    # no snapshot
    else:
        if name:
            message += f' - _{name}_'
        message += f': [{network}]({network_link})'
        if device:
            message += f' - _[{device}]({device_link})_'

    # Prevent the same message from being sent repeatedly in the lookback timeframe
    if already_duplicated(session, headers, message, user_email, lookback):
        message = 'MUTED!! ' + message
        print(message)

    # Wait a bit, for camera to upload snapshot to link
    elif alert == 'Motion detected' and message != '':
        time.sleep(5)
        post_file(session, headers, payload, message, photo)

    # Add more alert information and format JSON
    elif data:
        message += f'  \n```{json.dumps(data, indent=2, sort_keys=True)}'[:-1]  # screwy Webex Teams formatting
        post_message(session, headers, payload, message)

    # Send the webhook without alert data
    elif message != '':
        post_message(session, headers, payload, message)

    # Let Meraki know success
    return {
        'statusCode': 200,
        'body': json.dumps('webhook received')
    }
