import configparser
from datetime import datetime
from subprocess import Popen
import sys

import paho.mqtt.client as mqtt

from snapshot import *


LAST_TIME = 0
LAST_COUNT = 0


# Store credentials in a separate file
def gather_credentials():
    cp = configparser.ConfigParser()
    try:
        cp.read('credentials.ini')
        cam_key = cp.get('meraki', 'key2')
        net_id = cp.get('meraki', 'network')
        chatbot_token = cp.get('chatbot', 'token')
        user_email = cp.get('chatbot', 'email')
        mv_serial = cp.get('sense', 'serial')
    except:
        print('Missing credentials or input file!')
        sys.exit(2)
    return cam_key, net_id, chatbot_token, user_email, mv_serial


# The callback for when the client receives a CONNACK response from the server
def on_connect(client, userdata, flags, rc):
    print(f'Connected with result code {rc}')
    serial = userdata['mv_serial']

    # Subscribing in on_connect() means that if we lose the connection and
    # reconnect then subscriptions will be renewed.
    client.subscribe(f'/merakimv/{serial}/0')


# The callback for when a PUBLISH message is received from the server
def on_message(client, userdata, msg):
    datum = str(msg.payload)
    print(f'{msg.topic} {datum}')
    analyze(datum, userdata)


# Generic parse function
def parse(text, beg_tag, end_tag, beg_pos=0, end_pos=-1):
    if text.find(beg_tag, beg_pos, end_pos) == -1:
        return ('', -1)
    else:
        initial = text.find(beg_tag, beg_pos, end_pos) + len(beg_tag)
    if text.find(end_tag, initial) == -1:
        return ('', -1)
    else:
        final = text.find(end_tag, initial)
    return (text[initial:final], final+len(end_tag))


# Analyze MQTT and send message
def analyze(datum, userdata):
    global LAST_COUNT, LAST_TIME

    datum = str(datum)
    time = int(parse(datum, '{"ts":', ',')[0])
    count = int(parse(datum, '{"person":', '}}')[0])

    # Analyze only if people are detected
    if count > 0:
        # Either it's been a while, or count increasing
        if time > LAST_TIME + 30000 or count > LAST_COUNT:
            # Recalibrate
            LAST_TIME = time
            LAST_COUNT = count

            # Print message and send notification via chatbot
            plural = 'person' if count == 1 else 'people'
            message = f'{count} {plural} seen by Meraki MV camera!'
            print(f'#####\n#####\n#####\n{message}\n#####\n#####\n#####')
            Popen(f'python3 send.py {count}', shell=True)


# Main function
if __name__ == '__main__':
    # Get credentials
    (api_key, net_id, chatbot_token, user_email, mv_serial) = gather_credentials()
    user_data = {
        'api_key': api_key,
        'net_id': net_id,
        'chatbot_token': chatbot_token,
        'user_email': user_email,
        'mv_serial': mv_serial
    }

    # Start MQTT client
    client = mqtt.Client()
    client.user_data_set(user_data)
    client.on_connect = on_connect
    client.on_message = on_message
    client.connect('localhost', 1883, 300)

    # Blocking call that processes network traffic, dispatches callbacks and
    # handles reconnecting.
    # Other loop*() functions are available that give a threaded interface and a
    # manual interface.
    client.loop_forever()
