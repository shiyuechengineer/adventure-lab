import configparser
from subprocess import Popen
import sys

import paho.mqtt.client as mqtt
import requests

from status import *


LAST_TIME = 0
LAST_COUNT = 0
CONSECUTIVE_HITS = 0


# Store credentials in a separate file
def gather_credentials():
    cp = configparser.ConfigParser()
    try:
        cp.read('credentials.ini')
        cam_key = cp.get('meraki', 'key2')
        org_id = cp.get('meraki', 'organization')
        chatbot_token = cp.get('chatbot', 'token')
        user_email = cp.get('chatbot', 'email')
        mv_serial = cp.get('sense', 'serial')
    except:
        print('Missing credentials or input file!')
        sys.exit(2)
    return cam_key, org_id, chatbot_token, user_email, mv_serial


# The callback for when the client receives a CONNACK response from the server
def on_connect(client, user_data, flags, rc):
    print(f'Connected with result code {rc}')
    serial = user_data['mv_serial']

    # Subscribing in on_connect() means that if we lose the connection and
    # reconnect then subscriptions will be renewed.
    client.subscribe(f'/merakimv/{serial}/raw_detections')


# The callback for when a PUBLISH message is received from the server
def on_message(client, user_data, msg):
    datum = str(msg.payload)
    print(f'{msg.topic} {datum}')
    analyze(datum, user_data)


# Generic parse function
def parse(text, beg_tag, end_tag, beg_pos=0, end_pos=-1):
    if text.find(beg_tag, beg_pos, end_pos) == -1:
        return ('', -1)
    else:
        initial = text.find(beg_tag, beg_pos, end_pos) + len(beg_tag)
    if text.find(end_tag, initial) == -1:
        return ('', -1)
    else:
        final = text.find(end_tag, initial)
    return (text[initial:final], final+len(end_tag))

# Analyze MQTT and send message
def analyze(datum, user_data):
    global LAST_COUNT, LAST_TIME, CONSECUTIVE_HITS

    # Camera 4.0 firmware
    # datum = str(datum)
    # time = int(parse(datum, '{"ts":', ',')[0])
    # count = int(parse(datum, '{"person":', '}}')[0])

    # Camera 4.2 firmware
    time = datum['ts']
    count = len(datum['objects'])

    # Analyze only if people are detected
    if count > 0:
        CONSECUTIVE_HITS += 1
        # Either it's been a while or count increasing, and the last 5 MQTT messages have all been hits (seen people, not false positives)
        if (time > LAST_TIME + 30000 or count > LAST_COUNT) and CONSECUTIVE_HITS > 5:
            # Recalibrate
            LAST_TIME = time
            LAST_COUNT = count
            CONSECUTIVE_HITS = 0

            # Print message and send notification via chatbot
            plural = 'person' if count == 1 else 'people'
            message = f'{count} {plural} seen by MV camera {user_data["mv_name"]}'
            print(f'#####\n#####\n#####\n{message}\n#####\n#####\n#####')
            Popen(f'python3 send.py {count} {user_data["net_id"]} "{user_data["mv_name"]}"', shell=True)
    else:
        CONSECUTIVE_HITS = 0


# Main function
if __name__ == '__main__':
    # Get credentials
    (api_key, org_id, chatbot_token, user_email, mv_serial) = gather_credentials()
    user_data = {
        'api_key': api_key,
        'org_id': org_id,
        'chatbot_token': chatbot_token,
        'user_email': user_email,
        'mv_serial': mv_serial
    }

    # Get information about camera
    session = requests.Session()
    statuses = get_device_statuses(session, api_key, org_id)
    status = 'unknown'
    for device in statuses:
        if device['serial'] == mv_serial:
            net_id = device['networkId']
            mv_name = device['name']
            status = device['status']
            break
    if status != 'online':
        sys.exit(f'MV camera {mv_name} is not online!')
    else:
        user_data['net_id'] = net_id
        user_data['mv_name'] = mv_name

    # Start MQTT client
    client = mqtt.Client()
    client.user_data_set(user_data)
    client.on_connect = on_connect
    client.on_message = on_message
    client.connect('localhost', 1883, 300)

    # Blocking call that processes network traffic, dispatches callbacks and
    # handles reconnecting.
    # Other loop*() functions are available that give a threaded interface and a
    # manual interface.
    client.loop_forever()
