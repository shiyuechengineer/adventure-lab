import configparser
from datetime import datetime, timedelta
import json
import time
import sys

import requests


# Store credentials in a separate file
def gather_credentials():
    cp = configparser.ConfigParser()
    try:
        cp.read('credentials.ini')
        cam_key = cp.get('meraki', 'key2')
        net_id = cp.get('meraki', 'network')
        chatbot_token = cp.get('chatbot', 'token')
        user_email = cp.get('chatbot', 'email')
        mv_serial = cp.get('sense', 'serial')
        home_macs = cp.get('sense', 'home')
    except:
        print('Missing credentials or input file!')
        sys.exit(2)
    return cam_key, net_id, chatbot_token, user_email, mv_serial, home_macs


# List the devices in an organization
def get_net_clients(session, api_key, net_id, start_time):
    headers = {'X-Cisco-Meraki-API-Key': api_key, 'Content-Type': 'application/json'}
    response = session.get(f'https://api.meraki.com/api/v0/networks/{net_id}/clients?perPage=1000&t0={start_time}', headers=headers)
    return response.json()


# Main function
if __name__ == '__main__':
    # Get credentials and object count
    (api_key, net_id, chatbot_token, user_email, mv_serial, home_macs) = gather_credentials()
    count = int(sys.argv[1])

    # Establish session
    session = requests.Session()
    headers = {'X-Cisco-Meraki-API-Key': api_key}

    # Check if home devices are seen
    if home_macs:
        home_macs = home_macs.split(',')
        home_macs = [mac.strip() for mac in home_macs]
        time_now = datetime.utcnow()
        just_now = time_now - timedelta(minutes=3)
        start_time = datetime.isoformat(just_now) + 'Z'
        clients = get_net_clients(session, api_key, net_id, start_time)
        client_macs = [c['mac'] for c in clients]
        seen = set(home_macs).intersection(client_macs)

        # If so, no need to alert and exit
        if seen:
            sys.exit(0)

    # Retrieve snapshot
    response = session.post(
        f'https://api.meraki.com/api/v0/networks/{net_id}/cameras/{mv_serial}/snapshot',
        headers=headers)
    snapshot = response.json()['url']

    # Format message
    plural = 'person' if count == 1 else 'people'
    message = f'{count} {plural} seen by Meraki MV camera!'

    # Send message
    time.sleep(9)   # ensure snapshot link is ready
    headers = {
        'content-type': 'application/json; charset=utf-8',
        'authorization': f'Bearer {chatbot_token}'
    }
    payload = {
        'toPersonEmail': user_email,
        'markdown': message,
        'file': snapshot
    }
    response = session.post('https://api.ciscospark.com/v1/messages/',
         headers=headers,
         data=json.dumps(payload))
