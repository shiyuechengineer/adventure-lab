import configparser
import json
import time
import sys

import requests


# Store credentials in a separate file
def gather_credentials():
    cp = configparser.ConfigParser()
    try:
        cp.read('credentials.ini')
        cam_key = cp.get('meraki', 'key2')
        net_id = cp.get('meraki', 'network')
        chatbot_token = cp.get('chatbot', 'token')
        user_email = cp.get('chatbot', 'email')
        mv_serial = cp.get('sense', 'serial')
    except:
        print('Missing credentials or input file!')
        sys.exit(2)
    return cam_key, net_id, chatbot_token, user_email, mv_serial


# Main function
if __name__ == '__main__':
    # Get credentials
    (api_key, net_id, chatbot_token, user_email, mv_serial) = gather_credentials()
    user_data = {
        'api_key': api_key,
        'net_id': net_id,
        'chatbot_token': chatbot_token,
        'user_email': user_email,
        'mv_serial': mv_serial
    }

    count = int(sys.argv[1])

    # Establish session
    session = requests.Session()
    headers = {'X-Cisco-Meraki-API-Key': api_key}
    response = session.post(
        f'https://api.meraki.com/api/v0/networks/{net_id}/cameras/{mv_serial}/snapshot',
        headers=headers)
    snapshot = response.json()['url']

    # Format message
    plural = 'person' if count == 1 else 'people'
    message = f'{count} {plural} seen by Meraki MV camera!'

    # Send message
    time.sleep(7)   # ensure snapshot link is ready
    headers = {
        'content-type': 'application/json; charset=utf-8',
        'authorization': f'Bearer {chatbot_token}'
    }
    payload = {
        'toPersonEmail': user_email,
        'markdown': message,
        'file': snapshot
    }
    response = session.post('https://api.ciscospark.com/v1/messages/',
         headers=headers,
         data=json.dumps(payload))
